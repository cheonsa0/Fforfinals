   <section class="footer-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                   &copy; Library Management System |<a href="https://www.linkedin.com/in/manish-sahani/" target="_blank"  > Designed by : Manish Sahani</a> 
                </div>

            </div>
        </div>
    </section>
